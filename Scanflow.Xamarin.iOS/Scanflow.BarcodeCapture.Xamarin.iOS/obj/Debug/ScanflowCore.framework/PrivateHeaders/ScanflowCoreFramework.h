//
//  ScanflowCoreFramework.h
//  ScanflowCoreFramework
//
//  Created by Mac-OBS-46 on 02/09/22.
//

#import <Foundation/Foundation.h>

//! Project version number for ScanflowCoreFramework.
FOUNDATION_EXPORT double ScanflowCoreFrameworkVersionNumber;

//! Project version string for ScanflowCoreFramework.
FOUNDATION_EXPORT const unsigned char ScanflowCoreFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ScanflowCoreFramework/PublicHeader.h>


